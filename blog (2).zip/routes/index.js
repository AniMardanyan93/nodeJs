const express = require('express');
const router = express.Router();

/* GET home page. */
router.get('/', (req, res, next) => {
  res.render('index', { name: 'John' });
});

router.get('/contact', (req, res, next) => {
  res.send('contact');
});

router.get('/about', (req, res, next) => {
  res.send('about');
});

module.exports = router;
